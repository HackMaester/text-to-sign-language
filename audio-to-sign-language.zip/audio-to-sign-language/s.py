import nltk
nltk.download('popular')